import java.io.IOException;
import com.mradamantium.Display;

public class RecipeBookMain {

	public static void main(String[] args) throws IOException {
		Display theDisplay = new Display();
		theDisplay.setVisible(true);
	}
}
