package com.mradamantium;

import java.io.IOException;
import java.net.URL;
import com.mradamantium.Controller;
import com.mradamantium.StringToURL;
import com.mradamantium.WebPageParser;

public class Controller {
	public Controller( String test)throws IOException{
		String myUrl = test ;
		WebPageParser wpp = new WebPageParser();
		StringToURL stu = new StringToURL();
		URL url = stu.convertURL(myUrl);
		wpp.getWebPageSource(url);
	}
}

