package com.mradamantium;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebPageParser {

	public void getWebPageSource(URL url) throws IOException {
		try {

			Document doc = Jsoup.connect(url.toString()).get();

			StringBuilder ingredientSB = new StringBuilder();
			StringBuilder nutritentSB = new StringBuilder();
			StringBuilder infoSB = new StringBuilder();
			StringBuilder prepSB = new StringBuilder();
			
			String title = doc.title().replace(" | MyRecipes", "");

			//parses the webpage for the values

			Elements description = doc.select("div.description");
			Elements itemList = doc.select("ul#ingredient-data");
			Elements nutritionalInfo = doc.select("ul#nutritent-data");
			Elements preparation = doc.select("div.preparation");

			
			
			//removes tags and preserves white space
			for( Element ingredient : itemList.select("li") )
			{
				ingredientSB.append(ingredient.text()).append('\n');
			}
				
			//removes tags and preserves white space
			for( Element nutritent : nutritionalInfo.select("li") )
			{
				nutritentSB.append(nutritent.text()).append('\n');
			}
	
			//removes tags and preserves white space
			for( Element info : description.select("p") )
			{
				infoSB.append(info.text()).append('\n');
			}
			//removes tags and preserves white space
			for( Element prep : preparation.select("p") )
			{
				prepSB.append(prep.text()).append('\n');
			}
			System.out.println(title);
			System.out.println(infoSB);
			System.out.println(ingredientSB);
			System.out.println(prepSB);
			System.out.println(nutritentSB);
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

