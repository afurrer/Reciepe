package com.mradamantium;

import java.net.MalformedURLException;
import java.net.URL;

public class StringToURL {
	public URL url;
	public String myUrl;

	public URL convertURL(String myUrl)
	{

		try 
			{
			//String myUrl = "http://www.myrecipes.com/recipe/chicken-tamale-casserole/print";
			 url = new URL(myUrl);
			}
		catch (MalformedURLException e) 
			{
			e.printStackTrace();
			}
		return url;
	}
	
/*	public String getMyUrl() {
		return myUrl;
	}

	public void setMyUrl(String myUrl) {
		this.myUrl = myUrl;
	}
*/
	

}