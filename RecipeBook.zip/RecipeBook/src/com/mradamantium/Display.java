package com.mradamantium;

import javax.swing.JFrame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

//setup and display the window 
@SuppressWarnings("serial")
public class Display extends JFrame {

	// Creating fields for the JFrame

	private JButton submit = new JButton("Import");
	//private JButton close  = new JButton("Close");



	// Creating Labels for JFrame

	public Display() {
		//set up the window
		JPanel importedPage = new JPanel();
		this.setSize(400,100);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Adds Compnents to the bookpage
		JTextField urlField = new JTextField(20);
		importedPage.add(urlField);

		importedPage.add(submit);
		//	bookPage.add(close);

		// adds the bookPage to the Window
		this.add(importedPage);

		submit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				 createFrame(){
					
				}
				String test = urlField.getText();
				try {
					@SuppressWarnings("unused")
					Controller C = new Controller (test);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//System.out.println(test);
			}
		});
	}
}
