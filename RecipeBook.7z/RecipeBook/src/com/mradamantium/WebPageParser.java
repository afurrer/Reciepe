package com.mradamantium;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.stream.Stream;

import javax.swing.text.html.HTML;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebPageParser {

	public void getWebPabeSource(URL url) throws IOException {
		try {
			Document doc = Jsoup.connect(url.toString()).get();

			String title = doc.title().replace(" | MyRecipes", "");
			System.out.println(title);

			Document document = Jsoup.parse(doc.toString());
			StringBuilder sb = new StringBuilder();

		
			
			//this displays with html stripped
			Elements name = document.select("div.name");
			Elements description = document.select("div.description");
			Elements itemList = document.select("div.item-list");
			Elements preparation = document.select("div.preparation");
			Elements nutritionalInfo = document.select("div.nutritionalInfo");
			



			System.out.println(name.text());
			System.out.println(description.text());
			System.out.println(itemList.text());
			System.out.println(preparation.text());
			System.out.println(nutritionalInfo.text());
			
			//this displays with full html
			
		/*	String name2 = name.toString();
			String description2 = description.toString();
			String itemList2 = itemList.toString();
			String preparation2 = preparation.toString();
			String nutritionalInfo2 = nutritionalInfo.toString();
			
			System.out.println(name2);
			System.out.println(description2);
			System.out.println(itemList2);
			System.out.println(preparation2);
			System.out.println(nutritionalInfo2);*/
	
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	
	}
	public static String replaceLiWithNewLine(String itemList, String linebreakerString){
	    String result = "";
	    if(itemList.contains(linebreakerString)){
	        result = replaceLiWithNewLine(itemList, linebreakerString+"1");
	    } else {
	        result = Jsoup.parse(itemList.replaceAll("(?i)<li[^>]*>", linebreakerString)).text(); // replace and html line breaks with java linebreak.
	        result = result.replaceAll(linebreakerString, "\n");
	    }
	    System.out.println(result + "************************");
	    return result;
	   
	}
	
}
