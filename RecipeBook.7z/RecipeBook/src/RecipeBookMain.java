import java.io.IOException;
import java.net.URL;

import com.mradamantium.WebPageParser;

public class RecipeBookMain {

	public static void main(String[] args) throws IOException {
		WebPageParser wpp = new WebPageParser();
		URL url = new URL("http://www.myrecipes.com/recipe/chicken-tamale-casserole/print");
		wpp.getWebPabeSource(url);
	 
	}

}
